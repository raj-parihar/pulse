<?php

$_GLOBALS['mysqlconn'] = Array(
	"host" => "localhost",
	"user" => "root",
	"pass" => "root"
);

?>